import numpy as np
import sys
import matplotlib.pyplot as plt
import os
import struct

class ArtificialNeuralNetwork:
    def __init__(self, n_output, n_features, n_hidden=30,l2=0.0, epochs=500, eta=0.001,alpha=0.0, decrease_const=0.0, shuffle=True,minibatches=1, random_state=None):
        np.random.seed(random_state)
        self.eta=eta
        self.n_output=n_output
        self.epochs=epochs
        self.l2=l2
        self.n_hidden=n_hidden
        self.n_features=n_features
        self.W1=np.random.uniform(-1.0, 1.0,size=self.n_hidden*(self.n_features + 1))
        self.W1=self.W1.reshape(self.n_hidden, self.n_features + 1)
        self.W2=np.random.uniform(-1.0, 1.0,size=self.n_output*(self.n_hidden + 1))
        self.W2=self.W2.reshape(self.n_output, self.n_hidden + 1)
        self.decrease_const=decrease_const
        self.shuffle=shuffle
        self.alpha=alpha
        

        self.minibatches=minibatches
    def sigmoid(self,x):
     return 1 / (1 + np.exp(-x))

    def dervSig(self,Z):
        return self.sigmoid(Z)*(1-self.sigmoid(Z))
    def encode_labels(self,y, k):
        onehot = np.zeros((k, y.shape[0]))
        for idx, val in enumerate(y):
            onehot[val, idx] = 1.0
        return onehot
    def feedforward(self,X,W1,W2):
        x_new=np.ones((X.shape[0], X.shape[1]+1))
        x_new[:, 1:] = X
        X=x_new
        a1=X
        Z2=W1.dot(a1.T)
        a2=self.sigmoid(Z2)
        a_new=np.zeros((a2.shape[0]+1,a2.shape[1]))
        a_new[1:,:]=a2
        a2=a_new
        Z3=W2.dot(a2)
        a3=self.sigmoid(Z3)
        return a1,Z2,a2,Z3,a3

    def fit(self, X, y, print_progress=False):
        self.cost = []
        X_data, y_data = X.copy(), y.copy()
        y_enc = self.encode_labels(y, self.n_output)
        delta_w1_prev = np.zeros(self.W1.shape)
        delta_w2_prev = np.zeros(self.W2.shape)
        for i in range(self.epochs):
            # adaptive learning rate
            self.eta /= (1 + self.decrease_const*i)
            if print_progress:
                sys.stderr.write('\rEpoch: %d/%d' % (i+1, self.epochs))
                sys.stderr.flush()
            if self.shuffle:
                idx = np.random.permutation(y_data.shape[0])
                X_data, y_enc = X_data[idx], y_enc[:,idx]
                mini = np.array_split(range(y_data.shape[0]), self.minibatches)
            for idx in mini:
                # feedforward
                a1, z2, a2, z3, a3 = self.feedforward(X_data[idx], self.W1, self.W2)
                #Calculating the cost
                Y_enc=y_enc[:, idx].copy()
                W1,W2=self.W1,self.W2
                l1reg=(self.l2/2.0) * (np.abs(W1[:, 1:]).sum()+ np.abs(W2[:, 1:]).sum())
                cost=np.sum(-Y_enc*(np.log(a3))-(1-Y_enc)*np.log(1-a3))+l1reg
                self.cost.append(cost)

                #Compute the gradient.
                sigma3=a3-Y_enc
                z_new=np.zeros((z2.shape[0]+1,z2.shape[1]))
                z_new[1:,:]=z2
                z2=z_new
                sigma2=W2.T.dot(sigma3)*self.dervSig(z2)
                sigma2=sigma2[1:,:]
                grad1=sigma2.dot(a1)
                grad2=sigma3.dot(a2.T)
                grad1[:, 1:] += (W1[:, 1:] * self.l2)
                grad2[:, 1:] += (W2[:, 1:] * self.l2)

                delta_w1, delta_w2 = self.eta * grad1,self.eta * grad2
                self.W1 -= (delta_w1 + (self.alpha * delta_w1_prev))
                self.W2 -= (delta_w2 + (self.alpha * delta_w2_prev))
                delta_w1_prev, delta_w2_prev = delta_w1, delta_w2
        return self
    def predict(self, X):
        a1, z2, a2, z3, a3 = self.feedforward(X, self.W1, self.W2)
        y_pred = np.argmax(z3, axis=0)
        return y_pred



#This function has been written by Dr.Sebestian Rashka for reading the data.
#Importing and dividing the data.
def load_mnistTrain():
    labels_path = (r'train-labels.idx1-ubyte')
    images_path = (r'train-images.idx3-ubyte')
    with open(labels_path,'rb') as lbpath:
        magic, n = struct.unpack('>II',lbpath.read(8))
        labels = np.fromfile(lbpath,dtype=np.uint8)
    with open(images_path,'rb') as imgpath:
        magic, num, rows, cols = struct.unpack(">IIII",imgpath.read(16))
        images = np.fromfile(imgpath,dtype=np.uint8).reshape(len(labels), 784)
    return images, labels

def load_mnistTest():
    labels_path = (r't10k-labels.idx1-ubyte')
    images_path = (r't10k-images.idx3-ubyte')
    with open(labels_path,'rb') as lbpath:
        magic, n = struct.unpack('>II',lbpath.read(8))
        labels = np.fromfile(lbpath,dtype=np.uint8)
    with open(images_path,'rb') as imgpath:
        magic, num, rows, cols = struct.unpack(">IIII",imgpath.read(16))
        images = np.fromfile(imgpath,dtype=np.uint8).reshape(len(labels), 784)
    return images, labels
X_train, Y_train = load_mnistTrain()
X_test,Y_test=load_mnistTest()



ANN=ArtificialNeuralNetwork(n_output=10, n_features=X_train.shape[1], n_hidden=50,
                l2=0.1,epochs=1000,eta=0.001,alpha=0.001,decrease_const=0.00001,shuffle=True,minibatches=50,random_state=1)

ANN.fit(X_train,Y_train,print_progress=True)
result=ANN.predict(X_test)
acc = np.sum(Y_test_dub == result, axis=0) / X_test.shape[0]
print('Training accuracy: %.2f%%' % (acc * 100))
